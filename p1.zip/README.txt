//Nhut Ly - CS 559 - Fall 2021
I used arc(), eclipse() method to draw circle, eye, mouth, lineTo() to draw third eye, nose
Slider 1 is to adjust the eyes to change its form
Slider 2 is to adjust the mouth to change its form
Any combination of slider 1 and slider2 value gives out a certain emotion of the face